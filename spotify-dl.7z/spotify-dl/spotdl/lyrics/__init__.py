from spotdl.lyrics.lyric_base import LyricBase
