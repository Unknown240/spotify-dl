#Spotify Downloader - Beta
<p align="center">
  <img src="./hero.png" height="200px"/>
  <br><br>
  <b>Download audio files from spotify links</b>
  <br>
</p>

#Installation / Run
-7z x spotify-dl.7z
- " bash run "

#Spotify-Download
- Mengambil Lagu Dari Youtube
- Lagu ada di luar folder Spotify-dl, dan bernama "Music"
